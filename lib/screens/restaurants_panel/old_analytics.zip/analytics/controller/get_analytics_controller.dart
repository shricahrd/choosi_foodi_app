import 'dart:convert';
import 'dart:io';
import 'package:flutter/cupertino.dart';
import 'package:get/get.dart';
import 'package:open_filex/open_filex.dart';
import 'package:path_provider/path_provider.dart';
import 'package:syncfusion_flutter_xlsio/xlsio.dart';
import '../../../../core/http_utils/http_get_util.dart';
import '../../../../core/utils/app_constants.dart';
import '../../../../routes/general_path.dart';
import '../model/get_analytics_model.dart';
import '../model/get_custom_analytics_model.dart';

class GetAnalyticsController extends GetxController{
  GetAnalyticsModel getAnalyticsModel = GetAnalyticsModel();
  bool isLoaderVisible = false;
  List<AnalyticsResult> analyticsResult = [];

  callGetAnalyticsAPI() {
    isLoaderVisible = !isLoaderVisible;
    update();

    getRequest(GeneralPath.API_REST_ANALYTICS).then((response) {
      if (response.statusCode == 200) {
        Map<String, dynamic> mResponse = jsonDecode(response.body);

        getAnalyticsModel = GetAnalyticsModel.fromJson(mResponse);
        if (getAnalyticsModel.meta?.status == true) {
          debugPrint('status true: ${getAnalyticsModel.meta?.status}');
          analyticsResult.clear();
          
          for(int i=0; i<getAnalyticsModel.data!.data.length; i++){
            List<ListItem> newList=[];
            newList.addAll(getAnalyticsModel.data!.data[i].list);

            analyticsResult.add(AnalyticsResult(name: getAnalyticsModel.data!.data[i].user.firstName + " " + getAnalyticsModel.data!.data[i].user.lastName,
              cityName: getAnalyticsModel.data!.data[i].list[0].shippingAddress.cityName + "/" + getAnalyticsModel.data!.data[i].list[0].shippingAddress.pincode.toString(),
              analyticsSubList: newList,
            ));

            debugPrint('SDMain Len ====> : ${jsonEncode(analyticsResult.length)}');
            debugPrint('Sales sub Len ====> : ${jsonEncode(newList.length)}');
          }
          debugPrint('SDMain total Len ====> : ${jsonEncode(analyticsResult.length)}');
        }
        isLoaderVisible = !isLoaderVisible;
        update();
      } else {
        showToastMessage(getAnalyticsModel.meta?.msg?? "");
        isLoaderVisible = false;
        throw Exception('Failed to load data.');
      }
      update();
    });
  }

  Future<void> createExcel({required List<AnalyticsResult> analyticsResult}) async{
    final Workbook workbook = Workbook();
    final Worksheet sheet1 = workbook.worksheets[0];

    for(int i=1; i<= 7; i++){
      sheet1.getRangeByIndex(1, i).columnWidth = 19.86;
    }
    sheet1.getRangeByName('A1:L1').cellStyle.backColor = '#D9E1F2';
    sheet1.getRangeByName('A1:L1').cellStyle.hAlign = HAlignType.center;
    sheet1.getRangeByName('A1:L1').cellStyle.vAlign = VAlignType.center;
    sheet1.getRangeByName('A1:L1').cellStyle.bold = true;
    sheet1.getRangeByName('A1:L1').cellStyle.borders.all.lineStyle = LineStyle.thin;
    sheet1.getRangeByName('A1:L1').cellStyle.borders.all.color = '#BFBFBF';

    sheet1.getRangeByIndex(1, 1).text = 'Customer Name';
    sheet1.getRangeByIndex(1, 2).text = 'City Name/Pin Code';
    sheet1.getRangeByIndex(1, 3).text = 'Menu Item Name';
    sheet1.getRangeByIndex(1, 4).text = 'Price';
    sheet1.getRangeByIndex(1, 5).text = 'Total Quantity';
    sheet1.getRangeByIndex(1, 6).text = 'Sale Amount';

    if(analyticsResult.isNotEmpty) {
        debugPrint('analyticsResult length : ${analyticsResult.length}');
      for (int k = 0; k < analyticsResult.length; k++) {
          debugPrint('analyticsSubList length : ${analyticsResult[k].analyticsSubList.length}');
          sheet1.getRangeByIndex(k+2, 1).text = analyticsResult[k].analyticsSubList[0].userData.firstName + " " + analyticsResult[k].analyticsSubList[0].userData.lastName;
          sheet1.getRangeByIndex(k+2, 2).text = analyticsResult[k].analyticsSubList[0].shippingAddress.cityName + "/" + analyticsResult[k].analyticsSubList[0].shippingAddress.pincode.toString();
          sheet1.getRangeByIndex(k+2, 3).text = analyticsResult[k].analyticsSubList[0].productDetails[0].dishName;
          sheet1.getRangeByIndex(k+2, 4).text = analyticsResult[k].analyticsSubList[0].productDetails[0].price.toString();
          sheet1.getRangeByIndex(k+2, 5).text = analyticsResult[k].analyticsSubList[0].productDetails[0].selectQuantity.toString();
          sheet1.getRangeByIndex(k+2, 6).text = '${analyticsResult[k].analyticsSubList[0].productDetails[0].selectQuantity * analyticsResult[k].analyticsSubList[0].productDetails[0].price}';
          debugPrint('Index main: $k');
      }
    }

    final List<int> bytes = workbook.saveAsStream();
    workbook.dispose();

    final String path = (await getApplicationSupportDirectory()).path;
    final String fileName = '$path/Analytics.xlsx';
    final File file = File(fileName);
    await file.writeAsBytes(bytes, flush: true);
    debugPrint('FileName: $fileName');
    await OpenFilex.open(fileName);
  }

}
