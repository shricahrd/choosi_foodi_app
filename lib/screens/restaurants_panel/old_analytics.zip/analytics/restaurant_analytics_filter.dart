import 'package:choosifoodi/core/utils/app_color_utils.dart';
import 'package:choosifoodi/core/utils/app_font_utils.dart';
import 'package:choosifoodi/core/utils/app_images_utils.dart';
import 'package:choosifoodi/core/widgets/widget_button.dart';
import 'package:choosifoodi/core/widgets/widget_text.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:intl/intl.dart';
import 'package:syncfusion_flutter_datepicker/datepicker.dart';

import '../../../core/utils/app_strings_constants.dart';

String date = "";

class RestaurantAnalyticsFilterScreen extends StatefulWidget {
  @override
  _RestaurantAnalyticsFilterScreenState createState() =>
      _RestaurantAnalyticsFilterScreenState();
}

class _RestaurantAnalyticsFilterScreenState
    extends State<RestaurantAnalyticsFilterScreen> {
  bool isChecked = true;
  int selectedIndex = 0;
  DateRangePickerController _dateRangePickerController =
      DateRangePickerController();
  late String _startDate, _endDate;
  String? selectDeliveryType = delivery_type;
  List deliveryList = [delivery_type, pickup, delivery, scheduled];

  @override
  void initState() {
    _startDate = "";
    _endDate = "";
    super.initState();
  }

  void _onSelectionChanged(DateRangePickerSelectionChangedArgs args) {
    setState(() {
      _startDate =
          DateFormat('dd, MMMM yyyy').format(args.value.startDate).toString();
      _endDate = DateFormat('dd, MMMM yyyy')
          .format(args.value.endDate ?? args.value.startDate)
          .toString();
    });
  }

  void getDateRangePicker() {
    showDialog(
        context: context,
        builder: (BuildContext context) => Dialog(
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(20.0)),
              child: new Container(
                  height: MediaQuery.of(context).size.height / 2,
                  padding: EdgeInsets.all(10),
                  child: SfDateRangePicker(
                    view: DateRangePickerView.month,
                    monthViewSettings:
                        DateRangePickerMonthViewSettings(firstDayOfWeek: 6),
                    showActionButtons: true,
                    controller: _dateRangePickerController,
                    onSubmit: (val) {
                      Navigator.pop(context);
                    },
                    onCancel: () {
                      _dateRangePickerController.selectedRanges = null;
                      Navigator.pop(context);
                    },
                    selectionMode: DateRangePickerSelectionMode.range,
                    onSelectionChanged: _onSelectionChanged,
                  )),
            ));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(WHITE),
      resizeToAvoidBottomInset: false,
      appBar: AppBar(
        iconTheme: IconThemeData(
          color: Colors.transparent, //change your color here
        ),
        toolbarHeight: 60,
        shadowColor: Color(HINTCOLOR),
        backgroundColor: Color(WHITE),
        flexibleSpace: Container(
          height: double.infinity,
          padding: EdgeInsets.fromLTRB(15, 0, 15, 15),
          alignment: Alignment.bottomCenter,
          child: Row(
            crossAxisAlignment: CrossAxisAlignment.center,
            children: [
              InkWell(
                onTap: () {},
                child: Image.asset(
                  ic_right_side_arrow,
                  width: 25,
                  color: Color(ORANGE),
                  height: 20,
                ),
              ),
              SizedBox(
                width: 10,
              ),
              WidgetText.widgetPoppinsRegularText(
                filter,
                Color(BLACK),
                16,
              )
            ],
          ),
        ),
      ),
      body: SafeArea(
        child: Column(
          children: [
            SizedBox(
              height: 10,
            ),
            Container(
              width: MediaQuery.of(context).size.width,
              child: Card(
                // margin: EdgeInsets.fromLTRB(0, 10, 0, 10),
                margin: EdgeInsets.symmetric(horizontal: 15, vertical: 10),
                color: Color(WHITE),
                elevation: 5.0,
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(10.0),
                ),
                shadowColor: Color(BLACK),
                child: Container(
                  alignment: Alignment.centerLeft,
                  padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
                  child: DropdownButton(
                    underline: Container(),
                    borderRadius: BorderRadius.circular(10),
                    icon: Visibility(
                      visible: true,
                      child: Image.asset(
                        ic_down_arrow,
                        height: 10,
                        width: 20,
                        color: Color(DARKGREY),
                      ),
                    ),
                    isExpanded: true,
                    value: selectDeliveryType == delivery_type
                        ? deliveryList[0].toString()
                        : selectDeliveryType,
                    style: TextStyle(
                      color: Color(BLACK),
                      fontSize: 14,
                      fontFamily: FontPoppins,
                      fontWeight: PoppinsRegular,
                    ),
                    onChanged: (value) {
                      setState(() {
                        selectDeliveryType = value.toString();
                      });
                    },
                    items: deliveryList.map((dynamic value) {
                      return DropdownMenuItem<String>(
                        child: Text(
                          value,
                          style: TextStyle(
                            color: selectDeliveryType == delivery_type
                                ? Color(GREY2)
                                : Color(BLACK),
                            // color: Color(BLACK),
                            fontSize: 16,
                            fontFamily: FontRoboto,
                            fontWeight: RobotoRegular,
                          ),
                        ),
                        value: value,
                      );
                    }).toList(),
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Card(
              margin: EdgeInsets.symmetric(horizontal: 15, vertical: 10),
              color: Color(WHITE),
              elevation: 5.0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(12.0),
              ),
              child: Container(
                padding: EdgeInsets.fromLTRB(15, 0, 15, 0),
                child: TextFormField(
                  textAlign: TextAlign.start,
                  decoration: InputDecoration(
                    border: InputBorder.none,
                    hintStyle: TextStyle(
                      color: Color(GREY2),
                      fontSize: 14,
                      fontFamily: FontPoppins,
                      fontWeight: PoppinsMedium,
                    ),
                    hintText: city_zip_name,
                  ),
                  style: TextStyle(
                    color: Color(BLACK),
                    fontSize: 16,
                    fontFamily: FontPoppins,
                    fontWeight: PoppinsRegular,
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Card(
              margin: EdgeInsets.symmetric(horizontal: 15, vertical: 10),
              color: Color(WHITE),
              elevation: 5.0,
              shape: RoundedRectangleBorder(
                borderRadius: BorderRadius.circular(10.0),
              ),
              shadowColor: Color(BLACK),
              child: InkWell(
                onTap: () {
                  getDateRangePicker();
                },
                child: Container(
                  padding: EdgeInsets.all(15),
                  child: Row(
                    children: [
                      Expanded(
                        child: WidgetText.widgetPoppinsMediumText(
                          _startDate == ""
                              ? date_range
                              : _startDate + ' ' + to + ' ' + _endDate,
                          _startDate == "" ? Color(GREY2) : Color(BLACK),
                          // Color(GREYCOLORICON),
                          14,
                        ),
                      ),
                      Icon(
                        Icons.date_range,
                        size: 20.0,
                        color: Color(DARKGREY),
                      ),
                    ],
                  ),
                ),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            Container(
                margin: EdgeInsets.symmetric(horizontal: 20, vertical: 15),
                child: WidgetButton.widgetDefaultButton(filter, onClickExport)),
          ],
        ),
      ),
    );
  }

  onClickExport() {
    // Navigator.of(context).pushReplacement(MaterialPageRoute(
    //     builder: (BuildContext context) =>
    //         StartRScreen()));
  }
}
