import 'package:choosifoodi/core/utils/app_color_utils.dart';
import 'package:choosifoodi/core/utils/app_images_utils.dart';
import 'package:choosifoodi/core/utils/app_strings_constants.dart';
import 'package:choosifoodi/core/widgets/widget_button.dart';
import 'package:choosifoodi/core/widgets/widget_text.dart';
import 'package:choosifoodi/screens/restaurants_panel/analytics/view/restaurant_analytics_details.dart';
import 'package:choosifoodi/screens/restaurants_panel/analytics/restaurant_analytics_filter.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import 'package:get/get.dart';
import '../../../../core/utils/networkManager.dart';
import '../../../../core/widgets/widget_card.dart';
import '../controller/get_analytics_controller.dart';
import '../model/get_custom_analytics_model.dart';

class RestaurantAnalytics extends StatefulWidget {
  @override
  _RestaurantAnalyticsScreenState createState() =>
      _RestaurantAnalyticsScreenState();
}

class _RestaurantAnalyticsScreenState extends State<RestaurantAnalytics> {
  final GetAnalyticsController _getAnalyticsController =
      Get.put(GetAnalyticsController());
  final GetXNetworkManager _networkManager = Get.put(GetXNetworkManager());
  bool isChecked = true;

  @override
  void initState() {
    if (_networkManager.connectionType != 0) {
      print('Connection Type: ${_networkManager.connectionType}');
      _getAnalyticsController.callGetAnalyticsAPI();
    }
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(WHITE),
      appBar: WidgetAppbar.simpleAppBar(context, analytics, true),
      body: SafeArea(
          child: GetBuilder<GetXNetworkManager>(builder: (networkManager) {
        return networkManager.connectionType == 0
            ? Center(child: Text(check_internet))
            : Column(
                children: [
                  SizedBox(
                    height: 5,
                  ),
                  Container(
                    margin: EdgeInsets.all(15),
                    child: WidgetButton.widgetDefaultButton(
                        export_excel, (){
                        onClickExport(analyticsResult: _getAnalyticsController.analyticsResult);
                    }),
                  ),
                  Flexible(
                      flex: 1,
                      fit: FlexFit.tight,
                      child:
                      GetBuilder<GetAnalyticsController>(builder: (logic) {
                       return

                         logic.isLoaderVisible
                             ? Center(
                           child: CircularProgressIndicator(
                             color: Color(ORANGE),
                           ),
                         )
                             : logic.getAnalyticsModel.meta?.status == false
                             ? Container(
                           margin: EdgeInsets.symmetric(vertical: 20),
                           child: Text('No Analytics Found'),
                         )
                             :
                         ListView.builder(
                            shrinkWrap: true,
                            physics: BouncingScrollPhysics(),
                            itemCount: logic.analyticsResult.length,
                            itemBuilder: (context, index) {
                              return InkWell(
                                // onTap: onClickFoodDetail,
                                child: Container(
                                  margin: EdgeInsets.all(15),
                                  width: 280,
                                  child: Container(
                                    padding: EdgeInsets.all(10),
                                    decoration: BoxDecoration(
                                      color: Color(WHITE),
                                      shape: BoxShape.rectangle,
                                      border: Border.all(
                                          color: Color(ORANGE), width: 1),
                                      borderRadius:
                                          BorderRadius.all(Radius.circular(10)),
                                    ),
                                    child: Column(
                                      crossAxisAlignment:
                                          CrossAxisAlignment.start,
                                      children: [
                                        WidgetText.widgetPoppinsRegularText(
                                            customer_name + " ",
                                            Color(SUBTEXT),
                                            14),
                                        logic.analyticsResult[index].name.isEmpty ? Container():
                                        WidgetText.widgetPoppinsMediumText(
                                            // "Rahul Singh",
                                            logic.analyticsResult[index].name.toString(),
                                            Color(BLACK), 14),
                                        SizedBox(
                                          height: 15,
                                        ),
                                        WidgetText.widgetPoppinsRegularText(
                                            city_zip_name + " ",
                                            Color(SUBTEXT),
                                            14),
                                        logic.analyticsResult[index].cityName!.isEmpty ? Container():
                                        WidgetText.widgetPoppinsMediumText(
                                            // "Bhopal/462022",
                                            logic.analyticsResult[index].cityName.toString(),
                                            Color(BLACK), 14),
                                        SizedBox(
                                          height: 15,
                                        ),
                                        InkWell(
                                          onTap: (){
                                            Get.to(() => AnalyticsDetailsScreen(logic.analyticsResult[index].analyticsSubList));
                                          },
                                          child: Container(
                                            margin: EdgeInsets.symmetric(
                                                horizontal: 10, vertical: 10),
                                            padding: EdgeInsets.symmetric(
                                                horizontal: 10, vertical: 10),
                                            decoration: BoxDecoration(
                                              color: Color(WHITE),
                                              shape: BoxShape.rectangle,
                                              border: Border.all(
                                                  color: Color(ORANGE),
                                                  width: 1),
                                              borderRadius: BorderRadius.all(
                                                  Radius.circular(7)),
                                            ),
                                            alignment: Alignment.center,
                                            child: WidgetText
                                                .widgetPoppinsMediumText(
                                              view_detail,
                                              Color(ORANGE),
                                              16,
                                            ),
                                          ),
                                        ),
                                      ],
                                    ),
                                  ),
                                ),
                              );
                            })
                       ;
                      })
         /*             ListView.builder(
                          shrinkWrap: true,
                          physics: BouncingScrollPhysics(),
                          itemCount: 3,
                          itemBuilder: (context, index) {
                            return InkWell(
                              // onTap: onClickFoodDetail,
                              child: Container(
                                margin: EdgeInsets.all(15),
                                width: 280,
                                child: Container(
                                  padding: EdgeInsets.all(10),
                                  decoration: BoxDecoration(
                                    color: Color(WHITE),
                                    shape: BoxShape.rectangle,
                                    border: Border.all(
                                        color: Color(ORANGE), width: 1),
                                    borderRadius:
                                    BorderRadius.all(Radius.circular(10)),
                                  ),
                                  child: Column(
                                    crossAxisAlignment:
                                    CrossAxisAlignment.start,
                                    children: [
                                      WidgetText.widgetPoppinsRegularText(
                                          customer_name + " ",
                                          Color(SUBTEXT),
                                          14),
                                      // logic.getAnalyticsModel.data?.data[0].list[index].userData.firstName == null || logic.getAnalyticsModel.data?.data[0].list[index].userData.lastName == null ? Container():
                                      WidgetText.widgetPoppinsMediumText(
                                        "Rahul Singh",
                                        //   logic.getAnalyticsModel.data!.data[0].list[index].userData.firstName.toString() + " " + logic.getAnalyticsModel.data!.data[0].list[index].userData.lastName.toString(),
                                          Color(BLACK), 14),
                                      SizedBox(
                                        height: 15,
                                      ),
                                      WidgetText.widgetPoppinsRegularText(
                                          city_zip_name + " ",
                                          Color(SUBTEXT),
                                          14),
                                      // logic.getAnalyticsModel.data?.data[0].list[index].shippingAddress == null ? Container():
                                      WidgetText.widgetPoppinsMediumText(
                                          "Bhopal/462022",
                                          // logic.getAnalyticsModel.data!.data[0].list[index].shippingAddress.cityName.toString() + "/" +  logic.getAnalyticsModel.data!.data[0].list[index].shippingAddress.pincode.toString(),
                                          Color(BLACK), 14),
                                      SizedBox(
                                        height: 15,
                                      ),
                                      InkWell(
                                        onTap: onClickViewDetails,
                                        child: Container(
                                          margin: EdgeInsets.symmetric(
                                              horizontal: 10, vertical: 10),
                                          padding: EdgeInsets.symmetric(
                                              horizontal: 10, vertical: 10),
                                          decoration: BoxDecoration(
                                            color: Color(WHITE),
                                            shape: BoxShape.rectangle,
                                            border: Border.all(
                                                color: Color(ORANGE),
                                                width: 1),
                                            borderRadius: BorderRadius.all(
                                                Radius.circular(7)),
                                          ),
                                          alignment: Alignment.center,
                                          child: WidgetText
                                              .widgetPoppinsMediumText(
                                            view_detail,
                                            Color(ORANGE),
                                            16,
                                          ),
                                        ),
                                      ),
                                    ],
                                  ),
                                ),
                              ),
                            );
                          })*/

                  ),
                ],
              );
      })),
    );
  }

  onClickExport({required List<AnalyticsResult> analyticsResult}) {
    _getAnalyticsController.createExcel(analyticsResult: analyticsResult);
  }

  // onClickViewDetails() {
  //   Get.to(() => AnalyticsDetailsScreen());
  // }

  onClickFilter() {
    Navigator.of(context).push(MaterialPageRoute(
        builder: (BuildContext context) => RestaurantAnalyticsFilterScreen()));
  }
}

/* Container(
              margin: EdgeInsets.only(top: 10),
              padding: const EdgeInsets.symmetric(
                horizontal: 15,
              ),
              child: Row(
                children: [
                  InkWell(
                    onTap: onClickFilter,
                    child: Image.asset(
                      ic_filter,
                      width: 30,
                      color: Color(BLACK),
                      height: 30,
                    ),
                  ),
                  SizedBox(
                    width: 15,
                  ),
                  Flexible(
                    child: Container(
                      margin: EdgeInsets.fromLTRB(0, 10, 0, 10),
                      child: WidgetButton.widgetDefaultButton(
                          export_excel, onClickExport),
                    ),
                  ),
                ],
              ),
            ),*/
