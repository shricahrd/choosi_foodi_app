import 'package:choosifoodi/core/utils/app_color_utils.dart';
import 'package:choosifoodi/core/utils/app_images_utils.dart';
import 'package:choosifoodi/core/utils/app_strings_constants.dart';
import 'package:choosifoodi/core/widgets/widget_text.dart';
import 'package:choosifoodi/screens/restaurants_panel/analytics/restaurant_analytics_filter.dart';
import 'package:flutter/cupertino.dart';
import 'package:flutter/material.dart';
import '../../../../core/widgets/widget_card.dart';
import '../model/get_analytics_model.dart';

class AnalyticsDetailsScreen extends StatefulWidget {
  List<ListItem> analyticsSubResult = [];

  AnalyticsDetailsScreen(this.analyticsSubResult);

  @override
  _AnalyticsDetailsScreenState createState() => _AnalyticsDetailsScreenState(analyticsSubResult);
}

class _AnalyticsDetailsScreenState extends State<AnalyticsDetailsScreen> {

  List<ListItem> analyticsSubResult = [];

  _AnalyticsDetailsScreenState(List<ListItem> analyticsSubResult){
    this.analyticsSubResult = analyticsSubResult;
  }

  bool isChecked = true;

  @override
  void initState() {
    debugPrint('SubList: ${analyticsSubResult.length}');
    super.initState();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Color(WHITE),
      appBar: WidgetAppbar.simpleAppBar(context, view_detail, true),
      body: SafeArea(
        child: Column(
          children: [
            SizedBox(
              height: 5,
            ),
            Flexible(
              flex: 1,
              fit: FlexFit.tight,
              child: ListView.builder(
                  physics: BouncingScrollPhysics(),
                  itemCount: analyticsSubResult.length,
                  itemBuilder: (context, index) {

                    return Container(
                      margin: EdgeInsets.all(15),
                      width: 280,
                      child: Container(
                        padding: EdgeInsets.all(10),
                        decoration: BoxDecoration(
                          color: Color(WHITE),
                          shape: BoxShape.rectangle,
                          border: Border.all(color: Color(ORANGE), width: 1),
                          borderRadius: BorderRadius.all(Radius.circular(10)),
                        ),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            WidgetText.widgetPoppinsRegularText(
                                customer_name + " ", Color(SUBTEXT), 14),
                            SizedBox(
                              height: 5,
                            ),
                            WidgetText.widgetPoppinsMediumText(
                                analyticsSubResult[index].userData.firstName + " " +  analyticsSubResult[index].userData.lastName,
                                Color(BLACK), 14),
                            SizedBox(
                              height: 15,
                            ),

                            analyticsSubResult[index].shippingAddress.pincode != 0 ?
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                WidgetText.widgetPoppinsRegularText(
                                    city_zip_name + " ", Color(SUBTEXT), 14),
                                SizedBox(
                                  height: 5,
                                ),
                                WidgetText.widgetPoppinsMediumText(
                                    analyticsSubResult[index].shippingAddress.pincode == 0 ? (analyticsSubResult[index].shippingAddress.cityName) :
                                    (analyticsSubResult[index].shippingAddress.cityName + "/" + analyticsSubResult[index].shippingAddress.pincode.toString()),
                                    // cityPinCode.toString(),
                                    Color(BLACK), 14),
                                SizedBox(
                                  height: 15,
                                ),
                              ],
                            ): SizedBox(),
                            WidgetText.widgetPoppinsRegularText(
                                orderId, Color(SUBTEXT), 14),
                            SizedBox(
                              height: 5,
                            ),
                            WidgetText.widgetPoppinsMediumText(
                                analyticsSubResult[index].menuOrderID,
                                Color(BLACK), 14),


                            analyticsSubResult[index].paymentMethod == "online" ?
                            Column(
                              crossAxisAlignment: CrossAxisAlignment.start,
                              children: [
                                SizedBox(
                                  height: 15,
                                ),
                                WidgetText.widgetPoppinsRegularText(
                                    tranId, Color(SUBTEXT), 14),
                                SizedBox(
                                  height: 5,
                                ),
                                WidgetText.widgetPoppinsMediumText(
                                    analyticsSubResult[index].paymentDetails?.id ?? "",
                                    Color(BLACK), 14),
                                SizedBox(
                                  height: 15,
                                ),
                              ],
                            ): Container(),

                            ListView.builder(
                                shrinkWrap: true,
                                physics: BouncingScrollPhysics(),
                                itemCount: analyticsSubResult[index].productDetails.length,
                                itemBuilder: (BuildContext context, int i) {
                                    return Card(
                                      elevation: 0,
                                      color: Color(ITEMBGCOLOR),
                                      shape: RoundedRectangleBorder(
                                        borderRadius: BorderRadius.circular(10.0),
                                      ),
                                      child: Container(
                                        padding: EdgeInsets.all(15),
                                        child: Column(
                                          children: [
                                            Row(
                                              crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                              MainAxisAlignment.start,
                                              children: [
                                                Expanded(
                                                  child: Column(
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                    mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                    children: [
                                                      WidgetText
                                                          .widgetPoppinsRegularText(
                                                          menu_item,
                                                          Color(SUBTEXT),
                                                          13),
                                                      WidgetText
                                                          .widgetPoppinsMediumText(
                                                        // "Veg Biryani",
                                                          analyticsSubResult[index].productDetails[i].dishName,
                                                          Color(BLACK),
                                                          13),
                                                    ],
                                                  ),
                                                ),
                                                Expanded(
                                                  child: Column(
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                    mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                    children: [
                                                      WidgetText
                                                          .widgetPoppinsRegularText(
                                                          total_quantity,
                                                          Color(SUBTEXT),
                                                          13),
                                                      WidgetText
                                                          .widgetPoppinsMediumText(
                                                          analyticsSubResult[index].productDetails[i].selectQuantity.toString(),
                                                          Color(BLACK), 13),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                            SizedBox(
                                              height: 15,
                                            ),
                                            Row(
                                              crossAxisAlignment:
                                              CrossAxisAlignment.start,
                                              mainAxisAlignment:
                                              MainAxisAlignment.start,
                                              children: [
                                                Expanded(
                                                  child: Column(
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                    mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                    children: [
                                                      WidgetText
                                                          .widgetPoppinsRegularText(
                                                          price,
                                                          Color(SUBTEXT),
                                                          13),
                                                      WidgetText
                                                          .widgetPoppinsMediumText(
                                                          "\$" + analyticsSubResult[index].productDetails[i].price.toString(),
                                                          Color(BLACK),
                                                          13),
                                                    ],
                                                  ),
                                                ),
                                                Expanded(
                                                  child: Column(
                                                    crossAxisAlignment:
                                                    CrossAxisAlignment.start,
                                                    mainAxisAlignment:
                                                    MainAxisAlignment.start,
                                                    children: [
                                                      WidgetText
                                                          .widgetPoppinsRegularText(
                                                          sale_amount,
                                                          Color(SUBTEXT),
                                                          13),
                                                      WidgetText
                                                          .widgetPoppinsMediumText(
                                                        // "#1x5=\$1000",
                                                          "\$${analyticsSubResult[index].productDetails[i].price}x${analyticsSubResult[index].productDetails[i].selectQuantity}=\$${analyticsSubResult[index].productDetails[i].selectQuantity * analyticsSubResult[index].productDetails[i].price}",
                                                          Color(BLACK),
                                                          13),
                                                    ],
                                                  ),
                                                ),
                                              ],
                                            ),
                                          ],
                                        ),
                                      ),
                                    );
                              }),
                          ],
                        ),
                      ),
                    );
                  }),
            ),
          ],
        ),
      ),
    );
  }

  onClickExport() {}

  onClickFilter() {
    Navigator.of(context).push(MaterialPageRoute(
        builder: (BuildContext context) => RestaurantAnalyticsFilterScreen()));
  }
}
