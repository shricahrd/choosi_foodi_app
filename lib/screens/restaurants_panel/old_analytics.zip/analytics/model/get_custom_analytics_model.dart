
import 'get_analytics_model.dart';

class AnalyticsResult {
  String name = "";
  String? cityName = "";
  List<ListItem> analyticsSubList = [];

  AnalyticsResult(
      {required this.name, this.cityName, required this.analyticsSubList});
}
