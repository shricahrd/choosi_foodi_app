import '../../../home/model/safe_convert.dart';

class GetAnalyticsModel {
  final Meta? meta;
  final Data? data;

  GetAnalyticsModel({
     this.meta,
     this.data,
  });

  factory GetAnalyticsModel.fromJson(Map<String, dynamic>? json) => GetAnalyticsModel(
    meta: Meta.fromJson(asT<Map<String, dynamic>>(json, 'meta')),
    data: Data.fromJson(asT<Map<String, dynamic>>(json, 'data')),
  );

  Map<String, dynamic> toJson() => {
    'meta': meta?.toJson(),
    'data': data?.toJson(),
  };
}

class Meta {
  final String msg;
  final bool status;

  Meta({
    this.msg = "",
    this.status = false,
  });

  factory Meta.fromJson(Map<String, dynamic>? json) => Meta(
    msg: asT<String>(json, 'msg'),
    status: asT<bool>(json, 'status'),
  );

  Map<String, dynamic> toJson() => {
    'msg': msg,
    'status': status,
  };
}


class Data {
  final List<MetadataItem> metadata;
  final List<DataItem> data;

  Data({
    required this.metadata,
    required this.data,
  });

  factory Data.fromJson(Map<String, dynamic>? json) => Data(
    metadata: asT<List>(json, 'metadata').map((e) => MetadataItem.fromJson(e)).toList(),
    data: asT<List>(json, 'data').map((e) => DataItem.fromJson(e)).toList(),
  );

  Map<String, dynamic> toJson() => {
    'metadata': metadata.map((e) => e.toJson()).toList(),
    'data': data.map((e) => e.toJson()).toList(),
  };
}

class MetadataItem {
  final int total;
  final int page;

  MetadataItem({
    this.total = 0,
    this.page = 0,
  });

  factory MetadataItem.fromJson(Map<String, dynamic>? json) => MetadataItem(
    total: asT<int>(json, 'total'),
    page: asT<int>(json, 'page'),
  );

  Map<String, dynamic> toJson() => {
    'total': total,
    'page': page,
  };
}


class DataItem {
  final String id;
  final List<ListItem> list;
  final int count;
  final User user;

  DataItem({
    this.id = "",
    required this.list,
    this.count = 0,
    required this.user,
  });

  factory DataItem.fromJson(Map<String, dynamic>? json) => DataItem(
    id: asT<String>(json, '_id'),
    list: asT<List>(json, 'list').map((e) => ListItem.fromJson(e)).toList(),
    count: asT<int>(json, 'count'),
    user: User.fromJson(asT<Map<String, dynamic>>(json, 'user')),
  );

  Map<String, dynamic> toJson() => {
    '_id': id,
    'list': list.map((e) => e.toJson()).toList(),
    'count': count,
    'user': user.toJson(),
  };
}

class ListItem {
  final String id;
  final String menuOrderId;
  final int orderStatus;
  final List<ProductDetailsItem> productDetails;
  final String userId;
  final UserData userData;
  final int mobile;
  final String paymentMethod;
  final ShippingAddress shippingAddress;
  final double total;
  final int subTotal;
  final String menuOrderID;
  final int deliveryCharge;
  final int couponDiscount;
  final int deliveryDate;
  final String deviceType;
  final String specialRequest;
  final String restaurantId;
  final int deliveryCharges;
  final int tax;
  final double taxAmount;
  final int createdAt;
  final int updatedAt;
  final int v;
  final PaymentDetails? paymentDetails;

  ListItem({
    this.id = "",
    this.menuOrderId = "",
    this.orderStatus = 0,
    required this.productDetails,
    this.userId = "",
    required this.userData,
    this.mobile = 0,
    this.paymentMethod = "",
    required this.shippingAddress,
    this.total = 0.0,
    this.subTotal = 0,
    this.menuOrderID = "",
    this.deliveryCharge = 0,
    this.couponDiscount = 0,
    this.deliveryDate = 0,
    this.deviceType = "",
    this.specialRequest = "",
    this.restaurantId = "",
    this.deliveryCharges = 0,
    this.tax = 0,
    this.taxAmount = 0.0,
    this.createdAt = 0,
    this.updatedAt = 0,
    this.v = 0,
    this.paymentDetails,
  });

  factory ListItem.fromJson(Map<String, dynamic>? json) => ListItem(
    id: asT<String>(json, '_id'),
    menuOrderId: asT<String>(json, 'menuOrderId'),
    orderStatus: asT<int>(json, 'orderStatus'),
    productDetails: asT<List>(json, 'productDetails').map((e) => ProductDetailsItem.fromJson(e)).toList(),
    userId: asT<String>(json, 'userId'),
    userData: UserData.fromJson(asT<Map<String, dynamic>>(json, 'userData')),
    mobile: asT<int>(json, 'mobile'),
    paymentMethod: asT<String>(json, 'paymentMethod'),
    shippingAddress: ShippingAddress.fromJson(asT<Map<String, dynamic>>(json, 'shippingAddress')),
    total: asT<double>(json, 'total'),
    subTotal: asT<int>(json, 'subTotal'),
    menuOrderID: asT<String>(json, 'menuOrderID'),
    deliveryCharge: asT<int>(json, 'deliveryCharge'),
    couponDiscount: asT<int>(json, 'couponDiscount'),
    deliveryDate: asT<int>(json, 'deliveryDate'),
    deviceType: asT<String>(json, 'deviceType'),
    specialRequest: asT<String>(json, 'specialRequest'),
    restaurantId: asT<String>(json, 'restaurantId'),
    deliveryCharges: asT<int>(json, 'deliveryCharges'),
    tax: asT<int>(json, 'tax'),
    taxAmount: asT<double>(json, 'taxAmount'),
    createdAt: asT<int>(json, 'createdAt'),
    updatedAt: asT<int>(json, 'updatedAt'),
    v: asT<int>(json, '__v'),
    paymentDetails: PaymentDetails.fromJson(asT<Map<String, dynamic>>(json, 'paymentDetails')),
  );

  Map<String, dynamic> toJson() => {
    '_id': id,
    'menuOrderId': menuOrderId,
    'orderStatus': orderStatus,
    'productDetails': productDetails.map((e) => e.toJson()).toList(),
    'userId': userId,
    'userData': userData.toJson(),
    'mobile': mobile,
    'paymentMethod': paymentMethod,
    'shippingAddress': shippingAddress.toJson(),
    'total': total,
    'subTotal': subTotal,
    'menuOrderID': menuOrderID,
    'deliveryCharge': deliveryCharge,
    'couponDiscount': couponDiscount,
    'deliveryDate': deliveryDate,
    'deviceType': deviceType,
    'specialRequest': specialRequest,
    'restaurantId': restaurantId,
    'deliveryCharges': deliveryCharges,
    'tax': tax,
    'taxAmount': taxAmount,
    'createdAt': createdAt,
    'updatedAt': updatedAt,
    '__v': v,
    'paymentDetails': paymentDetails?.toJson(),
  };
}

class ProductDetailsItem {
  final String cartId;
  final String id;
  final String menuId;
  final int selectQuantity;
  final String dishName;
  final String foodOffered;
  final int price;
  final int specialPrice;
  final bool isVegetarian;
  final List<String> menuImg;

  ProductDetailsItem({
    this.cartId = "",
    this.id = "",
    this.menuId = "",
    this.selectQuantity = 0,
    this.dishName = "",
    this.foodOffered = "",
    this.price = 0,
    this.specialPrice = 0,
    this.isVegetarian = false,
    required this.menuImg,
  });

  factory ProductDetailsItem.fromJson(Map<String, dynamic>? json) => ProductDetailsItem(
    cartId: asT<String>(json, 'cartId'),
    id: asT<String>(json, '_id'),
    menuId: asT<String>(json, 'menuId'),
    selectQuantity: asT<int>(json, 'selectQuantity'),
    dishName: asT<String>(json, 'dishName'),
    foodOffered: asT<String>(json, 'foodOffered'),
    price: asT<int>(json, 'price'),
    specialPrice: asT<int>(json, 'specialPrice'),
    isVegetarian: asT<bool>(json, 'isVegetarian'),
    menuImg: asT<List>(json, 'menuImg').map((e) => e.toString()).toList(),
  );

  Map<String, dynamic> toJson() => {
    'cartId': cartId,
    '_id': id,
    'menuId': menuId,
    'selectQuantity': selectQuantity,
    'dishName': dishName,
    'foodOffered': foodOffered,
    'price': price,
    'specialPrice': specialPrice,
    'isVegetarian': isVegetarian,
    'menuImg': menuImg.map((e) => e).toList(),
  };
}

class PaymentDetails {
  final String id;
  final String object;
  final int amount;
  final int amountCaptured;
  final int amountRefunded;
  final dynamic application;
  final dynamic applicationFee;
  final dynamic applicationFeeAmount;
  final String balanceTransaction;
  final BillingDetails billingDetails;
  final String calculatedStatementDescriptor;
  final bool captured;
  final int created;
  final String currency;
  final String customer;
  final String description;
  final dynamic destination;
  final dynamic dispute;
  final bool disputed;
  final dynamic failureBalanceTransaction;
  final dynamic failureCode;
  final dynamic failureMessage;
  final dynamic invoice;
  final bool livemode;
  final dynamic onBehalfOf;
  final dynamic order;
  final bool paid;
  final dynamic paymentIntent;
  final String paymentMethod;
  final dynamic receiptEmail;
  final dynamic receiptNumber;
  final String receiptUrl;
  final bool refunded;
  final dynamic review;
  final dynamic shipping;
  final dynamic sourceTransfer;
  final dynamic statementDescriptor;
  final dynamic statementDescriptorSuffix;
  final String status;
  final dynamic transferData;
  final dynamic transferGroup;

  PaymentDetails({
    this.id = "",
    this.object = "",
    this.amount = 0,
    this.amountCaptured = 0,
    this.amountRefunded = 0,
    this.application,
    this.applicationFee,
    this.applicationFeeAmount,
    this.balanceTransaction = "",
    required this.billingDetails,
    this.calculatedStatementDescriptor = "",
    this.captured = false,
    this.created = 0,
    this.currency = "",
    this.customer = "",
    this.description = "",
    this.destination,
    this.dispute,
    this.disputed = false,
    this.failureBalanceTransaction,
    this.failureCode,
    this.failureMessage,
    this.invoice,
    this.livemode = false,
    this.onBehalfOf,
    this.order,
    this.paid = false,
    this.paymentIntent,
    this.paymentMethod = "",
    this.receiptEmail,
    this.receiptNumber,
    this.receiptUrl = "",
    this.refunded = false,
    this.review,
    this.shipping,
    this.sourceTransfer,
    this.statementDescriptor,
    this.statementDescriptorSuffix,
    this.status = "",
    this.transferData,
    this.transferGroup,
  });

  factory PaymentDetails.fromJson(Map<String, dynamic>? json) => PaymentDetails(
    id: asT<String>(json, 'id'),
    object: asT<String>(json, 'object'),
    amount: asT<int>(json, 'amount'),
    amountCaptured: asT<int>(json, 'amount_captured'),
    amountRefunded: asT<int>(json, 'amount_refunded'),
    application: asT<dynamic>(json, 'application'),
    applicationFee: asT<dynamic>(json, 'application_fee'),
    applicationFeeAmount: asT<dynamic>(json, 'application_fee_amount'),
    balanceTransaction: asT<String>(json, 'balance_transaction'),
    billingDetails: BillingDetails.fromJson(asT<Map<String, dynamic>>(json, 'billing_details')),
    calculatedStatementDescriptor: asT<String>(json, 'calculated_statement_descriptor'),
    captured: asT<bool>(json, 'captured'),
    created: asT<int>(json, 'created'),
    currency: asT<String>(json, 'currency'),
    customer: asT<String>(json, 'customer'),
    description: asT<String>(json, 'description'),
    destination: asT<dynamic>(json, 'destination'),
    dispute: asT<dynamic>(json, 'dispute'),
    disputed: asT<bool>(json, 'disputed'),
    failureBalanceTransaction: asT<dynamic>(json, 'failure_balance_transaction'),
    failureCode: asT<dynamic>(json, 'failure_code'),
    failureMessage: asT<dynamic>(json, 'failure_message'),
    invoice: asT<dynamic>(json, 'invoice'),
    livemode: asT<bool>(json, 'livemode'),
    onBehalfOf: asT<dynamic>(json, 'on_behalf_of'),
    order: asT<dynamic>(json, 'order'),
    paid: asT<bool>(json, 'paid'),
    paymentIntent: asT<dynamic>(json, 'payment_intent'),
    paymentMethod: asT<String>(json, 'payment_method'),
    receiptEmail: asT<dynamic>(json, 'receipt_email'),
    receiptNumber: asT<dynamic>(json, 'receipt_number'),
    receiptUrl: asT<String>(json, 'receipt_url'),
    refunded: asT<bool>(json, 'refunded'),
    review: asT<dynamic>(json, 'review'),
    shipping: asT<dynamic>(json, 'shipping'),
    sourceTransfer: asT<dynamic>(json, 'source_transfer'),
    statementDescriptor: asT<dynamic>(json, 'statement_descriptor'),
    statementDescriptorSuffix: asT<dynamic>(json, 'statement_descriptor_suffix'),
    status: asT<String>(json, 'status'),
    transferData: asT<dynamic>(json, 'transfer_data'),
    transferGroup: asT<dynamic>(json, 'transfer_group'),
  );

  Map<String, dynamic> toJson() => {
    'id': id,
    'object': object,
    'amount': amount,
    'amount_captured': amountCaptured,
    'amount_refunded': amountRefunded,
    'application': application,
    'application_fee': applicationFee,
    'application_fee_amount': applicationFeeAmount,
    'balance_transaction': balanceTransaction,
    'billing_details': billingDetails.toJson(),
    'calculated_statement_descriptor': calculatedStatementDescriptor,
    'captured': captured,
    'created': created,
    'currency': currency,
    'customer': customer,
    'description': description,
    'destination': destination,
    'dispute': dispute,
    'disputed': disputed,
    'failure_balance_transaction': failureBalanceTransaction,
    'failure_code': failureCode,
    'failure_message': failureMessage,
    'invoice': invoice,
    'livemode': livemode,
    'on_behalf_of': onBehalfOf,
    'order': order,
    'paid': paid,
    'payment_intent': paymentIntent,
    'payment_method': paymentMethod,
    'receipt_email': receiptEmail,
    'receipt_number': receiptNumber,
    'receipt_url': receiptUrl,
    'refunded': refunded,
    'review': review,
    'shipping': shipping,
    'source_transfer': sourceTransfer,
    'statement_descriptor': statementDescriptor,
    'statement_descriptor_suffix': statementDescriptorSuffix,
    'status': status,
    'transfer_data': transferData,
    'transfer_group': transferGroup,
  };
}

class BillingDetails {
  final Address address;
  final dynamic email;
  final dynamic name;
  final dynamic phone;

  BillingDetails({
    required this.address,
    this.email,
    this.name,
    this.phone,
  });

  factory BillingDetails.fromJson(Map<String, dynamic>? json) => BillingDetails(
    address: Address.fromJson(asT<Map<String, dynamic>>(json, 'address')),
    email: asT<dynamic>(json, 'email'),
    name: asT<dynamic>(json, 'name'),
    phone: asT<dynamic>(json, 'phone'),
  );

  Map<String, dynamic> toJson() => {
    'address': address.toJson(),
    'email': email,
    'name': name,
    'phone': phone,
  };
}

class Address {
  final String city;
  final String country;
  final String line1;
  final String line2;
  final String postalCode;
  final String state;

  Address({
    this.city = "",
    this.country = "",
    this.line1 = "",
    this.line2 = "",
    this.postalCode = "",
    this.state = "",
  });

  factory Address.fromJson(Map<String, dynamic>? json) => Address(
    city: asT<String>(json, 'city'),
    country: asT<String>(json, 'country'),
    line1: asT<String>(json, 'line1'),
    line2: asT<String>(json, 'line2'),
    postalCode: asT<String>(json, 'postal_code'),
    state: asT<String>(json, 'state'),
  );

  Map<String, dynamic> toJson() => {
    'city': city,
    'country': country,
    'line1': line1,
    'line2': line2,
    'postal_code': postalCode,
    'state': state,
  };
}

class UserData {
  final String userId;
  final String id;
  final String firstName;
  final String lastName;
  final int createdAt;
  final int updatedAt;
  final int v;

  UserData({
    this.userId = "",
    this.id = "",
    this.firstName = "",
    this.lastName = "",
    this.createdAt = 0,
    this.updatedAt = 0,
    this.v = 0,
  });

  factory UserData.fromJson(Map<String, dynamic>? json) => UserData(
    userId: asT<String>(json, 'userId'),
    id: asT<String>(json, '_id'),
    firstName: asT<String>(json, 'firstName'),
    lastName: asT<String>(json, 'lastName'),
    createdAt: asT<int>(json, 'createdAt'),
    updatedAt: asT<int>(json, 'updatedAt'),
    v: asT<int>(json, '__v'),
  );

  Map<String, dynamic> toJson() => {
    'userId': userId,
    '_id': id,
    'firstName': firstName,
    'lastName': lastName,
    'createdAt': createdAt,
    'updatedAt': updatedAt,
    '__v': v,
  };
}


class ShippingAddress {
  final String addressId;
  final String id;
  final String userId;
  final String name;
  final int mobile;
  final int pincode;
  final String addressLine1;
  final String landmark;
  final String cityId;
  final String cityName;
  final int createdAt;
  final int updatedAt;
  final int v;

  ShippingAddress({
    this.addressId = "",
    this.id = "",
    this.userId = "",
    this.name = "",
    this.mobile = 0,
    this.pincode = 0,
    this.addressLine1 = "",
    this.landmark = "",
    this.cityId = "",
    this.cityName = "",
    this.createdAt = 0,
    this.updatedAt = 0,
    this.v = 0,
  });

  factory ShippingAddress.fromJson(Map<String, dynamic>? json) => ShippingAddress(
    addressId: asT<String>(json, 'addressId'),
    id: asT<String>(json, '_id'),
    userId: asT<String>(json, 'userId'),
    name: asT<String>(json, 'name'),
    mobile: asT<int>(json, 'mobile'),
    pincode: asT<int>(json, 'pincode'),
    addressLine1: asT<String>(json, 'addressLine1'),
    landmark: asT<String>(json, 'landmark'),
    cityId: asT<String>(json, 'cityId'),
    cityName: asT<String>(json, 'cityName'),
    createdAt: asT<int>(json, 'createdAt'),
    updatedAt: asT<int>(json, 'updatedAt'),
    v: asT<int>(json, '__v'),
  );

  Map<String, dynamic> toJson() => {
    'addressId': addressId,
    '_id': id,
    'userId': userId,
    'name': name,
    'mobile': mobile,
    'pincode': pincode,
    'addressLine1': addressLine1,
    'landmark': landmark,
    'cityId': cityId,
    'cityName': cityName,
    'createdAt': createdAt,
    'updatedAt': updatedAt,
    '__v': v,
  };
}


class User {
  final String id;
  final String userId;
  final String firstName;
  final String lastName;
  final String mobile;
  final int createdAt;
  final int updatedAt;

  User({
    this.id = "",
    this.userId = "",
    this.firstName = "",
    this.lastName = "",
    this.mobile = "",
    this.createdAt = 0,
    this.updatedAt = 0,
  });

  factory User.fromJson(Map<String, dynamic>? json) => User(
    id: asT<String>(json, '_id'),
    userId: asT<String>(json, 'userId'),
    firstName: asT<String>(json, 'firstName'),
    lastName: asT<String>(json, 'lastName'),
    mobile: asT<String>(json, 'mobile'),
    createdAt: asT<int>(json, 'createdAt'),
    updatedAt: asT<int>(json, 'updatedAt'),
  );

  Map<String, dynamic> toJson() => {
    '_id': id,
    'userId': userId,
    'firstName': firstName,
    'lastName': lastName,
    'mobile': mobile,
    'createdAt': createdAt,
    'updatedAt': updatedAt,
  };
}

